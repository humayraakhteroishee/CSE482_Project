<?php


//incluse constant.php
include('../config/constants.php');
//get the Id of admin to delete

$id = $_GET['id'];
//create sql query to delete Admin
$sql = "DELETE FROM admin WHERE id=$id";
//execute the query
$res = mysqli_query($conn, $sql);
// check whether it execute or not
if($res==true)
{
  //query executed and admin deletes
  //echo "Admin Deleted";
  //session variable to display message
  $_SESSION['delete'] = "<div class ='succes'>Admin Deleted Succesfully</div>";
  //redirect to header funtion
  header("location:" .SITEURL.'admin/manage-admin.php');
}
else
{
  //failed to delete admin
  //echo "Failed to Delete Admin";
  $_SESSION['delete'] = "<div class='error'>Failed to Delete Admin</div>";
  //redirect page
  header("location:" .SITEURL.'admin/add-admin.php');
}

//redirect manage admin page with message
?>
