<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

       <div class="box">
           <h3>Locations</h3>
           <a href="#">Banani</a>
           <a href="#">Gulshan</a>
           <a href="#">Bashundhara</a>
           <a href="#">Nikunju</a>
           <a href="#">Uttara</a>
       </div>

       <div class="box">
           <h3>Quick Links</h3>
           <a href="#">home</a>
           <a href="#">dishes</a>
           <a href="#">about</a>
           <a href="#">menu</a>
           <a href="#">reivew</a>
           <a href="#">order</a>
       </div>

       <div class="box">
           <h3>Contact Info</h3>
           <a href="#">+880-1921-7853</a>
           <a href="#">+111-222-333</a>
           <a href="#">khananamy002@gmail.com</a>
           <a href="#">humayra@gmail.com</a>
           <a href="#">Gulshan-Dhaka-1219</a>
       </div>

       <div class="box">
           <h3>Follow Us</h3>
           <a href="#">facebook</a>
           <a href="#">twitter</a>
           <a href="#">instagram</a>
           <a href="#">linkedin</a>
       </div>

   </div>

   <div class="credit"> copyright @ 2022 by <span>GROUP 11</span>
     <p>Sadiya Afrose Anamika & Humayra Akhter Oishee</p>
    </div>

</section>
</body>
</html>
