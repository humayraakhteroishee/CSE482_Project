<?php
  include('../config/constants.php');
  /*include('login-check.php'); */

?>
<html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOODIST</title>
    <link rel="icon" type="image/x-icon" href="favicon.io.jpg">
    <link rel="stylesheet" href="style.css">

<body>
  <!--Menu section starts-->
  <div class="menu text-center">
    <div class="wraper">
    <ul>
      <li><a href="home.php">Home</a></li>
      <li><a href="manage-admin.php">Admin </a></li>
      <li><a href="manage-category.php">Category</a></li>
      <li><a href="manage-food.php">Food</a></li>
      <li><a href="manage-order.php">Order</a></li>
      <li><a href="logout.php">Logout</a></li>

    </ul>
  </div>
  </div>
    <!--Menu section ends-->
