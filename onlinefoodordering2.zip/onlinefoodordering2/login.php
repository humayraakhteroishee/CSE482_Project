

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FOODIST</title>
    <link rel="icon" type="image/x-icon" href="favicon.io.jpg">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section>
        <div class="form-container">
            <h2>Login Form</h2>


        <form action="index.php" method="post">
            <div class="control">
            <label for="name">Name</label>
            <input type="text" id="user" name="user" placeholder="Enter Username"></div>
            <div class="control">
            <label for="psw">Password</label>
            <input type="password" id="pass" name="pass" placeholder="Enter Password"></div>
            <div class="control">
            <input type="submit" id="btn" value="Login">
            </div>
        </form>
        <div class="link">
            <a href="#">Forget password ?</a>
        </div>
    </div>

    </section>

</body>
</html>
